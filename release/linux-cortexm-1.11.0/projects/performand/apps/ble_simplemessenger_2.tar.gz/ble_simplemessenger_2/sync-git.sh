#! /bin/sh

rsync -av . ~/gitWorkspace/uCLinux-Bluetooth4.0/
